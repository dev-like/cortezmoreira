-- MySQL dump 10.13  Distrib 5.7.23-23, for Linux (x86_64)
--
-- Host: localhost    Database: laborato_db
-- ------------------------------------------------------
-- Server version	5.7.23-23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `caminho` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `texto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `textobotao` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `corbotao` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lado` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
INSERT INTO `banner` (`id`, `caminho`, `ordem`, `video`, `titulo`, `texto`, `link`, `textobotao`, `corbotao`, `lado`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'1591392455.a.jpg',NULL,NULL,'Uma família para cuidar da sua','Contamos com os melhores profissionais para cuidar da sua família.',NULL,'Saiba Mais',NULL,NULL,'2020-06-05 21:27:35','2020-06-05 21:27:35',NULL),(2,'1591392547.b.jpg',NULL,NULL,'Equipamentos de qualidade','Temos os melhores equipamentos da cidade.',NULL,'Saiba Mais',NULL,NULL,'2020-06-05 21:29:07','2020-06-05 21:29:07',NULL);
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coleta`
--

DROP TABLE IF EXISTS `coleta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coleta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` varchar(550) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coleta`
--

LOCK TABLES `coleta` WRITE;
/*!40000 ALTER TABLE `coleta` DISABLE KEYS */;
/*!40000 ALTER TABLE `coleta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `convenios`
--

DROP TABLE IF EXISTS `convenios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `convenios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descricao` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `convenios`
--

LOCK TABLES `convenios` WRITE;
/*!40000 ALTER TABLE `convenios` DISABLE KEYS */;
INSERT INTO `convenios` (`id`, `descricao`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'CAIXA SAÚDE','2020-06-05 23:48:59','2020-06-05 23:48:59',NULL),(2,'BRADESCO','2020-06-05 23:49:12','2020-06-05 23:49:12',NULL),(3,'ASSEMBLÉIA - ACESP','2020-06-05 23:49:26','2020-06-05 23:49:26',NULL),(4,'ASSEFAZ','2020-06-05 23:49:42','2020-06-05 23:49:42',NULL),(5,'CAMED','2020-06-05 23:49:53','2020-06-05 23:49:53',NULL),(6,'CASF','2020-06-05 23:50:08','2020-06-05 23:50:08',NULL),(7,'CASSI','2020-06-05 23:50:16','2020-06-05 23:50:16',NULL),(8,'CORREIOS','2020-06-08 12:27:09','2020-06-08 12:27:09',NULL),(9,'ELETRONORTE','2020-06-08 12:27:19','2020-06-08 12:27:19',NULL),(10,'FUSEX','2020-06-08 12:27:33','2020-06-08 12:27:33',NULL),(11,'GEAP','2020-06-08 12:27:41','2020-06-08 12:27:41',NULL),(12,'OAB','2020-06-08 12:27:49','2020-06-08 12:27:49',NULL),(13,'PORTAL SAUDE','2020-06-08 12:27:58','2020-06-08 12:27:58',NULL),(14,'SESI','2020-06-08 12:28:06','2020-06-08 12:28:06',NULL),(15,'SUL AMERICA','2020-06-08 12:28:15','2020-06-08 12:28:15',NULL),(16,'UNIMED','2020-06-08 12:28:25','2020-06-08 12:28:25',NULL),(17,'VALE/PASA','2020-06-08 12:28:32','2020-06-08 12:28:32',NULL);
/*!40000 ALTER TABLE `convenios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corpo_clinico`
--

DROP TABLE IF EXISTS `corpo_clinico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corpo_clinico` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crf` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagem` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corpo_clinico`
--

LOCK TABLES `corpo_clinico` WRITE;
/*!40000 ALTER TABLE `corpo_clinico` DISABLE KEYS */;
INSERT INTO `corpo_clinico` (`id`, `nome`, `crf`, `descricao`, `imagem`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Dr. André Tavares','CRF/MA 1538','Análises Clinicas','1591398752.1571228557.a.jpg','2020-06-05 23:12:32','2020-06-05 23:14:21','2020-06-05 23:14:21'),(2,'Dr. André Tavares','CRF/MA 1538','Análises Clinicas','1591399228.1571228557.a.jpg','2020-06-05 23:20:28','2020-06-05 23:20:28',NULL),(3,'Dra. Flávia Soares','CRF/MA 1946','Microbiologia e Citologia Clinica','1591399278.1571228557.a.jpg','2020-06-05 23:21:18','2020-06-05 23:21:18',NULL),(4,'Dr. Ítalo Chrystinno','CRF/MA 2629','Hematologia','1591399323.1571228557.a.jpg','2020-06-05 23:22:03','2020-06-05 23:22:03',NULL),(5,'Dra. Maria das Graças','CRF/MA 301','Analises Clínicas','1591399413.1571228557.a.jpg','2020-06-05 23:23:33','2020-06-05 23:23:33',NULL);
/*!40000 ALTER TABLE `corpo_clinico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomefantasia` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `missao` varchar(850) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visao` varchar(850) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valores` varchar(850) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` (`id`, `nomefantasia`, `telefone`, `whatsapp`, `email`, `endereco`, `missao`, `visao`, `valores`, `instagram`, `facebook`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Laboratório Cortez Moreira','(99) 3524-3600','(99) 99102-0416','contato@labcortezmoreira.com.br','Rua Piauí, 882 - Centro Imperatriz - MA','Realizar análises clínicas de qualidade garantindo confiança, precisão e rapidez no cuidado com a saúde.','Tornar-se uma escolha inequívoca para clientes e profissionais de saúde em análises clínicas na região.','Respeito nos relacionamentos, aprendizado em equipe, sustentabilidade, integridade, segurança, credibilidade, foco no cliente e transparência.','https://www.instagram.com/labcortezmoreira/','https://www.facebook.com/labcortezmoreira/',NULL,'2020-06-08 13:53:00',NULL);
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_site`
--

DROP TABLE IF EXISTS `info_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_site` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `resultado_exame` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sobre_titulo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sobre_texto` varchar(2500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premios_texto` varchar(350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_exames` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `corpoclinico_texto` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `convenio_texto` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_site`
--

LOCK TABLES `info_site` WRITE;
/*!40000 ALTER TABLE `info_site` DISABLE KEYS */;
INSERT INTO `info_site` (`id`, `resultado_exame`, `sobre_titulo`, `sobre_texto`, `premios_texto`, `link_exames`, `corpoclinico_texto`, `convenio_texto`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Resultado de Exames','Um laboratório completo para sua família','<p>O Laboratório Cortez Moreira foi fundado em 1975 com uma área de 62 m2 e com 3 funcionários. Seus sócios-diretores fundadores são a Dra. Maria das Graças Cortez Moreira e o Dr. Antônio Tavares de Araújo. Após várias expansões, atualmente ocupa uma área de 324 m2, na qual estão distribuídos todos os seus setores administrativos e técnicos com 18 funcionários.&nbsp;<br>Sua estrutura física conta atualmente com: sala de recepção, sala de espera, 4 salas de coletas, secretaria, sala de administração, 2 salas de escritório, vestiário, 4 banheiros, sala técnica, sala de cultura, &nbsp;sala de cpd, sala de acasalamento, sala de parasitologia e urinálise, &nbsp;recepção e coleta para sus, sala para treinamento, depósito, sala de lavagem de material e sala de esterilização.<br>Em virtude do desenvolvimento técnico científico, o laboratório se aparelhou com equipamentos automatizados em: &nbsp;bioquímica, hematologia, imunologia e hormônio, além de outros equipamentos necessários para atender a demanda dos exames atualmente requisitados pela clínica médica. Atualmente o Laboratório Cortez Moreira realiza em média 25.000 exames / mês. O laboratório Cortez Moreira está à disposição dos médicos, clínicas e das empresas de saúde para realizar exames nas especialidades de:&nbsp;</p><ul><li>Bioquímica</li><li>Parasitologia</li><li>Hematologia</li><li>Urinálise</li><li>Citologia</li><li>Hormônios</li><li>Microbiologia</li><li>Anatomia patológica&nbsp;<br>&nbsp;</li></ul><p>A fim de controlar a qualidade de seus exames nas diferentes áreas, o laboratório possui um sistema de controle interno de qualidade e participa do programa nacional de controle de qualidade (pncq): programa externo da qualidade patrocinado pela sociedade brasileira de análises clinicas, do qual vem sempre recebendo avaliação \"excelente\".&nbsp;</p>',NULL,'http://cortezmoreira.dlinkddns.com:9090/auth',NULL,NULL,'2020-06-05 21:18:10','2020-06-08 13:50:30',NULL);
/*!40000 ALTER TABLE `info_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `acoes` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`id`, `user`, `descricao`, `acoes`, `date`) VALUES (1,'Like Admin','{\"texto\":\"O Alvaro \\u00e9 um dos maiores laborat\\u00f3rios de apoio do Brasil e refer\\u00eancia no mercado desde 1968. Com vasta experi\\u00eancia e presen\\u00e7a em todo pa\\u00eds\",\"imagem\":\"1591398383.alvaro.png\",\"updated_at\":\"2020-06-05 20:06:23\",\"created_at\":\"2020-06-05 20:06:23\",\"id\":1}','Adicionou o parceiro \"1\"','2020-06-05 20:06:23'),(2,'Like Admin','{\"texto\":\"Hermes Pardini conta, hoje, com cerca de 5,5 mil laborat\\u00f3rios parceiros, com os quais est\\u00e1 em contato constante, na busca por aprimorar seus servi\\u00e7os a partir do entendimento da realidade e das necessidades dos clientes.\",\"imagem\":\"1591398447.pardini.png\",\"updated_at\":\"2020-06-05 20:07:27\",\"created_at\":\"2020-06-05 20:07:27\",\"id\":2}','Adicionou o parceiro \"2\"','2020-06-05 20:07:27'),(3,'Like Admin','{\"texto\":\"O Diagn\\u00f3sticos do Brasil \\u00e9 o \\u00fanico laborat\\u00f3rio exclusivo de apoio do pa\\u00eds, ou seja, presta servi\\u00e7o de terceiriza\\u00e7\\u00e3o de exames de forma \\u00e9tica e transparente sem oferecer nenhuma rela\\u00e7\\u00e3o de concorr\\u00eancia com os seus clientes\",\"imagem\":\"1591398524.diagn.png\",\"updated_at\":\"2020-06-05 20:08:44\",\"created_at\":\"2020-06-05 20:08:44\",\"id\":3}','Adicionou o parceiro \"3\"','2020-06-05 20:08:44'),(4,'Like Admin','{\"texto\":\"Criado em 2003 com o objetivo de desenvolver atividades de educa\\u00e7\\u00e3o, pesquisa e de responsabilidade social, o Instituto Fleury obteve resultados consistentes nessas tr\\u00eas \\u00e1reas, tornando-se uma refer\\u00eancia diante da comunidade m\\u00e9dica.\",\"imagem\":\"1591398594.fleury.png\",\"updated_at\":\"2020-06-05 20:09:54\",\"created_at\":\"2020-06-05 20:09:54\",\"id\":4}','Adicionou o parceiro \"4\"','2020-06-05 20:09:54'),(5,'Like Admin','{\"nome\":\"Dr. Andr\\u00e9 Tavares\",\"crf\":\"CRF\\/MA 1538\",\"descricao\":\"An\\u00e1lises Clinicas\",\"imagem\":\"1591398752.1571228557.a.jpg\",\"updated_at\":\"2020-06-05 20:12:32\",\"created_at\":\"2020-06-05 20:12:32\",\"id\":1}','Adicionou o clinico \"Dr. André Tavares\"','2020-06-05 20:12:32'),(6,'Like Admin','{\"id\":1,\"nome\":\"Dr. Andr\\u00e9 Tavares\",\"crf\":\"CRF\\/MA 1538\",\"descricao\":\"An\\u00e1lises Clinicas\",\"imagem\":\"1591398752.1571228557.a.jpg\",\"created_at\":\"2020-06-05 20:12:32\",\"updated_at\":\"2020-06-05 20:14:21\",\"deleted_at\":\"2020-06-05 20:14:21\"}','Deletou o clinico \"Dr. André Tavares\"','2020-06-05 20:14:21'),(7,'Like Admin','{\"rua\":\"R. Piau\\u00ed\",\"bairro\":\"Centro\",\"numero\":\"882\",\"updated_at\":\"2020-06-05 20:16:30\",\"created_at\":\"2020-06-05 20:16:30\",\"id\":1}','Adicionou a unidade da rua\"R. Piauí\"','2020-06-05 20:16:30'),(8,'Like Admin','{\"nome\":\"Dr. Andr\\u00e9 Tavares\",\"crf\":\"CRF\\/MA 1538\",\"descricao\":\"An\\u00e1lises Clinicas\",\"imagem\":\"1591399228.1571228557.a.jpg\",\"updated_at\":\"2020-06-05 20:20:28\",\"created_at\":\"2020-06-05 20:20:28\",\"id\":2}','Adicionou o clinico \"Dr. André Tavares\"','2020-06-05 20:20:28'),(9,'Like Admin','{\"nome\":\"Dra. Fl\\u00e1via Soares\",\"crf\":\"CRF\\/MA 1946\",\"descricao\":\"Microbiologia e Citologia Clinica\",\"imagem\":\"1591399278.1571228557.a.jpg\",\"updated_at\":\"2020-06-05 20:21:18\",\"created_at\":\"2020-06-05 20:21:18\",\"id\":3}','Adicionou o clinico \"Dra. Flávia Soares\"','2020-06-05 20:21:18'),(10,'Like Admin','{\"nome\":\"Dr. \\u00cdtalo Chrystinno\",\"crf\":\"CRF\\/MA 2629\",\"descricao\":\"Hematologia\",\"imagem\":\"1591399323.1571228557.a.jpg\",\"updated_at\":\"2020-06-05 20:22:03\",\"created_at\":\"2020-06-05 20:22:03\",\"id\":4}','Adicionou o clinico \"Dr. Ítalo Chrystinno\"','2020-06-05 20:22:03'),(11,'Like Admin','{\"nome\":\"Dra. Maria das Gra\\u00e7as\",\"crf\":\"CRF\\/MA 301\",\"descricao\":\"Analises Cl\\u00ednicas\",\"imagem\":\"1591399413.1571228557.a.jpg\",\"updated_at\":\"2020-06-05 20:23:33\",\"created_at\":\"2020-06-05 20:23:33\",\"id\":5}','Adicionou o clinico \"Dra. Maria das Graças\"','2020-06-05 20:23:33'),(12,'Like Admin','{\"id\":1,\"nomefantasia\":\"Laborat\\u00f3rio Cortez Moreira\",\"telefone\":\"(99) 3524-3600,(99) 98108-0073\",\"whatsapp\":\"(99) 99102-0416\",\"email\":\"contato@labcortezmoreira.com.br\",\"endereco\":\"Rua Piau\\u00ed, 882 - Centro Imperatriz - MA\",\"missao\":\".\",\"visao\":\".\",\"valores\":\".\",\"instagram\":\"https:\\/\\/www.instagram.com\\/labcortezmoreira\\/\",\"facebook\":\"https:\\/\\/www.facebook.com\\/labcortezmoreira\\/\",\"created_at\":null,\"updated_at\":\"2020-06-05 20:25:01\",\"deleted_at\":null}','Editou as informações da Empresa','2020-06-05 20:25:01'),(13,'Like Admin','{\"id\":1,\"nomefantasia\":\"Laborat\\u00f3rio Cortez Moreira\",\"telefone\":\"(99) 3524-3600\",\"whatsapp\":\"(99) 99102-0416\",\"email\":\"contato@labcortezmoreira.com.br\",\"endereco\":\"Rua Piau\\u00ed, 882 - Centro Imperatriz - MA\",\"missao\":\".\",\"visao\":\".\",\"valores\":\".\",\"instagram\":\"https:\\/\\/www.instagram.com\\/labcortezmoreira\\/\",\"facebook\":\"https:\\/\\/www.facebook.com\\/labcortezmoreira\\/\",\"created_at\":null,\"updated_at\":\"2020-06-05 20:39:10\",\"deleted_at\":null}','Editou as informações da Empresa','2020-06-05 20:39:10'),(14,'Like Admin','{\"descricao\":\"CAIXA SA\\u00daDE\",\"updated_at\":\"2020-06-05 20:48:59\",\"created_at\":\"2020-06-05 20:48:59\",\"id\":1}','Adicionou o convenio \"CAIXA SAÚDE\"','2020-06-05 20:48:59'),(15,'Like Admin','{\"descricao\":\"BRADESCO\",\"updated_at\":\"2020-06-05 20:49:12\",\"created_at\":\"2020-06-05 20:49:12\",\"id\":2}','Adicionou o convenio \"BRADESCO\"','2020-06-05 20:49:12'),(16,'Like Admin','{\"descricao\":\"ASSEMBL\\u00c9IA - ACESP\",\"updated_at\":\"2020-06-05 20:49:26\",\"created_at\":\"2020-06-05 20:49:26\",\"id\":3}','Adicionou o convenio \"ASSEMBLÉIA - ACESP\"','2020-06-05 20:49:26'),(17,'Like Admin','{\"descricao\":\"ASSEFAZ\",\"updated_at\":\"2020-06-05 20:49:42\",\"created_at\":\"2020-06-05 20:49:42\",\"id\":4}','Adicionou o convenio \"ASSEFAZ\"','2020-06-05 20:49:42'),(18,'Like Admin','{\"descricao\":\"CAMED\",\"updated_at\":\"2020-06-05 20:49:53\",\"created_at\":\"2020-06-05 20:49:53\",\"id\":5}','Adicionou o convenio \"CAMED\"','2020-06-05 20:49:53'),(19,'Like Admin','{\"descricao\":\"CASF\",\"updated_at\":\"2020-06-05 20:50:08\",\"created_at\":\"2020-06-05 20:50:08\",\"id\":6}','Adicionou o convenio \"CASF\"','2020-06-05 20:50:08'),(20,'Like Admin','{\"descricao\":\"CASSI\",\"updated_at\":\"2020-06-05 20:50:16\",\"created_at\":\"2020-06-05 20:50:16\",\"id\":7}','Adicionou o convenio \"CASSI\"','2020-06-05 20:50:16'),(21,'Like Admin','{\"descricao\":\"CORREIOS\",\"updated_at\":\"2020-06-08 09:27:09\",\"created_at\":\"2020-06-08 09:27:09\",\"id\":8}','Adicionou o convenio \"CORREIOS\"','2020-06-08 09:27:09'),(22,'Like Admin','{\"descricao\":\"ELETRONORTE\",\"updated_at\":\"2020-06-08 09:27:19\",\"created_at\":\"2020-06-08 09:27:19\",\"id\":9}','Adicionou o convenio \"ELETRONORTE\"','2020-06-08 09:27:19'),(23,'Like Admin','{\"descricao\":\"FUSEX\",\"updated_at\":\"2020-06-08 09:27:33\",\"created_at\":\"2020-06-08 09:27:33\",\"id\":10}','Adicionou o convenio \"FUSEX\"','2020-06-08 09:27:33'),(24,'Like Admin','{\"descricao\":\"GEAP\",\"updated_at\":\"2020-06-08 09:27:41\",\"created_at\":\"2020-06-08 09:27:41\",\"id\":11}','Adicionou o convenio \"GEAP\"','2020-06-08 09:27:41'),(25,'Like Admin','{\"descricao\":\"OAB\",\"updated_at\":\"2020-06-08 09:27:49\",\"created_at\":\"2020-06-08 09:27:49\",\"id\":12}','Adicionou o convenio \"OAB\"','2020-06-08 09:27:49'),(26,'Like Admin','{\"descricao\":\"PORTAL SAUDE\",\"updated_at\":\"2020-06-08 09:27:58\",\"created_at\":\"2020-06-08 09:27:58\",\"id\":13}','Adicionou o convenio \"PORTAL SAUDE\"','2020-06-08 09:27:58'),(27,'Like Admin','{\"descricao\":\"SESI\",\"updated_at\":\"2020-06-08 09:28:06\",\"created_at\":\"2020-06-08 09:28:06\",\"id\":14}','Adicionou o convenio \"SESI\"','2020-06-08 09:28:06'),(28,'Like Admin','{\"descricao\":\"SUL AMERICA\",\"updated_at\":\"2020-06-08 09:28:15\",\"created_at\":\"2020-06-08 09:28:15\",\"id\":15}','Adicionou o convenio \"SUL AMERICA\"','2020-06-08 09:28:15'),(29,'Like Admin','{\"descricao\":\"UNIMED\",\"updated_at\":\"2020-06-08 09:28:25\",\"created_at\":\"2020-06-08 09:28:25\",\"id\":16}','Adicionou o convenio \"UNIMED\"','2020-06-08 09:28:25'),(30,'Like Admin','{\"descricao\":\"VALE\\/PASA\",\"updated_at\":\"2020-06-08 09:28:32\",\"created_at\":\"2020-06-08 09:28:32\",\"id\":17}','Adicionou o convenio \"VALE/PASA\"','2020-06-08 09:28:32'),(31,'Like Admin','{\"id\":1,\"nomefantasia\":\"Laborat\\u00f3rio Cortez Moreira\",\"telefone\":\"(99) 3524-3600\",\"whatsapp\":\"(99) 99102-0416\",\"email\":\"contato@labcortezmoreira.com.br\",\"endereco\":\"Rua Piau\\u00ed, 882 - Centro Imperatriz - MA\",\"missao\":\"Realizar an\\u00e1lises cl\\u00ednicas de qualidade garantindo confian\\u00e7a, precis\\u00e3o e rapidez no cuidado com a sa\\u00fade.\",\"visao\":\"Tornar-se uma escolha inequ\\u00edvoca para clientes e profissionais de sa\\u00fade em an\\u00e1lises cl\\u00ednicas na regi\\u00e3o.\",\"valores\":\"Respeito nos relacionamentos, aprendizado em equipe, sustentabilidade, integridade, seguran\\u00e7a, credibilidade, foco no cliente e transpar\\u00eancia.\",\"instagram\":\"https:\\/\\/www.instagram.com\\/labcortezmoreira\\/\",\"facebook\":\"https:\\/\\/www.facebook.com\\/labcortezmoreira\\/\",\"created_at\":null,\"updated_at\":\"2020-06-08 10:53:00\",\"deleted_at\":null}','Editou as informações da Empresa','2020-06-08 10:53:00');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2017_11_22_195826_create_logs',1),(4,'2018_07_18_131959_create_empresa_table',1),(5,'2018_07_18_132030_create_quem_somos_table',1),(6,'2018_07_18_132819_create_banner_table',1),(7,'2019_09_03_101825_create_unidades_table',1),(8,'2019_09_03_103510_create_info_site_table',1),(9,'2019_09_03_103511_create_parceiros_table',1),(10,'2019_09_03_103512_create_premios_table',1),(11,'2019_09_03_103513_create_convenios_table',1),(12,'2019_09_03_103514_create_corpo_clinico_table',1),(13,'2019_10_17_174933_create_events_table',1),(14,'2019_10_19_174933_create_coleta_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parceiros`
--

DROP TABLE IF EXISTS `parceiros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parceiros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imagem` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `texto` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parceiros`
--

LOCK TABLES `parceiros` WRITE;
/*!40000 ALTER TABLE `parceiros` DISABLE KEYS */;
INSERT INTO `parceiros` (`id`, `imagem`, `texto`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'1591398383.alvaro.png','O Alvaro é um dos maiores laboratórios de apoio do Brasil e referência no mercado desde 1968. Com vasta experiência e presença em todo país','2020-06-05 23:06:23','2020-06-05 23:06:23',NULL),(2,'1591398447.pardini.png','Hermes Pardini conta, hoje, com cerca de 5,5 mil laboratórios parceiros, com os quais está em contato constante, na busca por aprimorar seus serviços a partir do entendimento da realidade e das necessidades dos clientes.','2020-06-05 23:07:27','2020-06-05 23:07:27',NULL),(3,'1591398524.diagn.png','O Diagnósticos do Brasil é o único laboratório exclusivo de apoio do país, ou seja, presta serviço de terceirização de exames de forma ética e transparente sem oferecer nenhuma relação de concorrência com os seus clientes','2020-06-05 23:08:44','2020-06-05 23:08:44',NULL),(4,'1591398594.fleury.png','Criado em 2003 com o objetivo de desenvolver atividades de educação, pesquisa e de responsabilidade social, o Instituto Fleury obteve resultados consistentes nessas três áreas, tornando-se uma referência diante da comunidade médica.','2020-06-05 23:09:54','2020-06-05 23:09:54',NULL);
/*!40000 ALTER TABLE `parceiros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premios`
--

DROP TABLE IF EXISTS `premios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imagem` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premios`
--

LOCK TABLES `premios` WRITE;
/*!40000 ALTER TABLE `premios` DISABLE KEYS */;
/*!40000 ALTER TABLE `premios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quem_somos`
--

DROP TABLE IF EXISTS `quem_somos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quem_somos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `texto` text COLLATE utf8mb4_unicode_ci,
  `imagem` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quem_somos`
--

LOCK TABLES `quem_somos` WRITE;
/*!40000 ALTER TABLE `quem_somos` DISABLE KEYS */;
/*!40000 ALTER TABLE `quem_somos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidades`
--

DROP TABLE IF EXISTS `unidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unidades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rua` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidades`
--

LOCK TABLES `unidades` WRITE;
/*!40000 ALTER TABLE `unidades` DISABLE KEYS */;
INSERT INTO `unidades` (`id`, `rua`, `bairro`, `numero`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'R. Piauí','Centro','882','2020-06-05 23:16:30','2020-06-05 23:16:30',NULL);
/*!40000 ALTER TABLE `unidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `nome`, `email`, `password`, `nivel`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Like Admin','dev@likepublicidade.com','$2y$10$tVtC9RYzhV2vUwBeX/Z1p.ODKrBEvkV0Vgbn0LFYuGGQ8pYo4FVpS',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'laborato_db'
--

--
-- Dumping routines for database 'laborato_db'
--
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-10 10:54:43
